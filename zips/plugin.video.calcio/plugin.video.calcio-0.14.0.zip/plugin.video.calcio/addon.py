import sys
from pathlib import Path
from urllib.parse import parse_qs, urlencode

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmc

from catalog import SPORTS, SourceError, get_events, get_sources, resolve_event, league_sort_key
from artwork import league_image
from competitions import canonical_league


def main():
    addon = xbmcaddon.Addon()
    handle = int(sys.argv[1])
    params = parse_qs(sys.argv[2].lstrip("?"))
    action = params.get("action", [""])[0]
    sport = params.get("sport", [""])[0]
    if sport == "Calcio":
        sport = "Calcio maschile"
    playing = action == "event_play"
    try:
        if sport not in SPORTS:
            if playing:
                raise SourceError("Categoria della partita non valida.")
            for name in SPORTS:
                target = sys.argv[0] + "?" + urlencode({"sport": name})
                item = xbmcgui.ListItem(label=name)
                image = str(Path(__file__).parent / "resources" / (SPORTS[name] + ".png"))
                item.setArt({"thumb": image, "icon": image, "poster": image})
                xbmcplugin.addDirectoryItem(handle, target, item, True)
        elif playing:
            key = params.get("key", [""])[0]
            url = resolve_event(key, sport, int(params.get("source", ["0"])[0]))
            manifest, _, headers = url.partition("|")
            item = xbmcgui.ListItem(path=manifest)
            item.setContentLookup(False)
            item.setMimeType("application/vnd.apple.mpegurl")
            item.setProperty("inputstream", "inputstream.adaptive")
            if int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0]) < 21:
                item.setProperty("inputstream.adaptive.manifest_type", "hls")
            item.setProperty("inputstream.adaptive.manifest_headers", headers)
            item.setProperty("inputstream.adaptive.stream_headers", headers)
            xbmcplugin.setResolvedUrl(handle, True, item)
            return
        elif action == "event_links":
            key = params.get("key", [""])[0]
            events = get_events(sport)
            event = next((event for event in events if event["key"] == key), None)
            if not event:
                raise SourceError("Evento rimosso dal catalogo. Riapri la categoria.")
            sources = get_sources(key, sport)
            for index, source in enumerate(sources):
                item = xbmcgui.ListItem(label="Player {} | {}".format(index + 1, event["title"]))
                item.setArt({"thumb": event["image"], "icon": event["image"], "poster": event["image"]})
                item.setProperty("IsPlayable", "true")
                target = sys.argv[0] + "?" + urlencode({"action": "event_play", "sport": sport, "key": key, "source": index})
                xbmcplugin.addDirectoryItem(handle, target, item, False)
            if not sources:
                xbmcgui.Dialog().ok(addon.getAddonInfo("name"), "Nessun player attivo per questa partita. Riprova vicino all'orario di inizio.")
        else:
            events = get_events(sport)
            league = canonical_league(params.get("league", [""])[0], sport)
            if sport in ("Calcio maschile", "Calcio femminile", "Football americano") and not league:
                for name in sorted({event["league"] for event in events}, key=lambda name: league_sort_key(name, sport)):
                    target = sys.argv[0] + "?" + urlencode({"sport": sport, "league": name})
                    item = xbmcgui.ListItem(label=name)
                    image = league_image(name, SPORTS[sport])
                    item.setArt({"thumb": image, "icon": image, "poster": image})
                    xbmcplugin.addDirectoryItem(handle, target, item, True)
                if not events:
                    xbmcgui.Dialog().ok(addon.getAddonInfo("name"), "Nessuna partita in corso per oggi")
                xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
                return
            if league and sport in ("Calcio maschile", "Calcio femminile", "Football americano"):
                events = [event for event in events if event["league"] == league]
            for event in events:
                target = sys.argv[0] + "?" + urlencode({"action": "event_links", "sport": sport, "key": event["key"]})
                item = xbmcgui.ListItem(label="{} | {}".format(event["time"], event["title"]))
                item.setArt({"thumb": event["image"], "icon": league_image(event["league"], SPORTS[sport]),
                             "poster": event["image"], "banner": league_image(event["league"], SPORTS[sport])})
                xbmcplugin.addDirectoryItem(handle, target, item, True)
            if not events:
                xbmcgui.Dialog().ok(addon.getAddonInfo("name"), "Nessuna partita in corso per oggi")
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        message = str(exc) if isinstance(exc, SourceError) else "Impossibile caricare l'evento o il player. Riapri la categoria e riprova."
        xbmcgui.Dialog().ok(addon.getAddonInfo("name"), message)
        if playing:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == "__main__":
    main()
