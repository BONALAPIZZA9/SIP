"""Eventi ZicoTV e player HLS pubblici associati al loro ID."""
import json
import re
from datetime import datetime
from urllib.parse import urlencode, urljoin, urlsplit

from events import SourceError, USER_AGENT, event_image, matches_football, fetch_page, http_url

BASE = "https://bp.zicotv.cc/"
SPORTS = {"Calcio maschile": "Soccer", "Calcio femminile": "Soccer", "Pallavolo": "Volleyball", "Football americano": "American Football",
          "Basket": "Basketball", "Hockey": "Ice Hockey", "Baseball": "Baseball", "UFC": "Fighting", "F1": "Motorsport"}


def read(path):
    try:
        return fetch_page(urljoin(BASE, path), BASE)[0]
    except SourceError as exc:
        raise SourceError("ZicoTV non raggiungibile o richiesta negata.") from exc


def identity(key):
    if not re.fullmatch(r"zico:[1-9][0-9]*", key):
        raise SourceError("ID evento ZicoTV non valido.")
    return key.split(":")[1]


def parse_events(data, sport):
    try:
        leagues = data["eventsBySport"].get(SPORTS[sport], {}).get("leagues", {})
        if not isinstance(leagues, dict):
            raise ValueError()
    except (KeyError, TypeError, AttributeError, ValueError) as exc:
        raise SourceError("Formato eventi ZicoTV non valido.") from exc
    result = []
    seen = set()
    for league_name, rows in leagues.items():
        if not isinstance(rows, list):
            continue
        for event in rows:
            if not isinstance(event, dict) or (not event.get("has_stream") and event.get("status") != "scheduled") or event.get("live_status") in ("FT", "AET", "PEN") or event.get("status") in ("finished", "cancelled", "postponed"):
                continue
            league = str(event.get("league", "")).upper()
            if not matches_football(sport, league, str(event.get("title", ""))):
                continue
            if sport == "UFC" and "UFC" not in league:
                continue
            if sport == "F1" and not re.search(r"\bF1\b|FORMULA (?:1|ONE)", league):
                continue
            try:
                key = "zico:" + str(event["id"])
                identity(key)
                date = datetime.fromisoformat(event["start_time"]).astimezone()
                title = event["title"].strip()
                image = event_image(sport, BASE, event.get("thumbnail_url"), event.get("home_team_badge"), event.get("away_team_badge"))
            except (ValueError, KeyError, TypeError, AttributeError):
                continue
            if not title or key in seen:
                continue
            seen.add(key)
            result.append({"key": key, "title": title, "sport": sport,
                           "time": date.strftime("%d/%m %H:%M"), "timestamp": date.timestamp(), "image": image,
                           "league": str(event.get("league") or league_name or "").strip() or "Altri campionati"})
    return sorted(result, key=lambda event: event["timestamp"])


def get_events(sport):
    try:
        response = json.loads(read("/api/v1/events"))
        if not isinstance(response, dict) or not isinstance(response.get("data"), list):
            raise ValueError()
        rows = [row for row in response["data"] if isinstance(row, dict) and row.get("sport_category") == SPORTS[sport]]
        data = {"eventsBySport": {SPORTS[sport]: {"leagues": {"": rows}}}}
    except ValueError as exc:
        if isinstance(exc, SourceError):
            raise
        raise SourceError("Risposta eventi ZicoTV non valida.") from exc
    return parse_events(data, sport)


def get_sources(key, sport):
    try:
        response = json.loads(read("/api/v1/events/" + identity(key)))
        event = response["data"]
        if not isinstance(event, dict) or not isinstance(event.get("sources"), list):
            raise ValueError()
    except (ValueError, KeyError, TypeError) as exc:
        if isinstance(exc, SourceError):
            raise
        raise SourceError("Risposta API ZicoTV non valida.") from exc
    if str(event.get("id")) != identity(key) or event.get("sport_category") != SPORTS[sport]:
        raise SourceError("ZicoTV non conferma l'abbinamento della partita.")
    sources = []
    for source in event["sources"]:
        if not isinstance(source, dict) or source.get("source") != "own" or source.get("is_premium") or not source.get("is_streaming"):
            continue
        url = source.get("player_url", "")
        if not isinstance(url, str):
            continue
        parsed = urlsplit(url)
        if parsed.scheme == "https" and parsed.hostname == urlsplit(BASE).hostname and re.fullmatch(r"/api/player/[0-9]+", parsed.path):
            if url not in sources:
                sources.append(url)
    return sources


def resolve_event(key, sport, source_index=0):
    sources = get_sources(key, sport)
    if not 0 <= source_index < len(sources):
        raise SourceError("Nessun player pubblico ZicoTV disponibile per questo evento.")
    player = sources[source_index]
    html = read(player)
    if re.search(r"var ZT_(?:PREMIUM_GATE|CONN_LIMIT)\s*=\s*true", html):
        raise SourceError("Questo player richiede l'accesso tramite ZicoTV.")
    match = re.search(r'var ZT_STREAM_URL\s*=\s*("(?:[^"\\]|\\.)*")\s*;', html)
    if not match:
        raise SourceError("Il player ZicoTV non espone un flusso HLS pubblico.")
    stream = http_url(json.loads(match[1]))
    if not urlsplit(stream).path.endswith(".m3u8"):
        raise SourceError("Formato video ZicoTV non supportato.")
    # shortcut: URL temporaneo della fonte, serve rinnovo in sessione per visioni oltre la scadenza.
    return stream + "|" + urlencode({"User-Agent": USER_AGENT, "Referer": player, "Origin": BASE.rstrip("/")})
