"""Stemmi locali e segnaposto dei campionati, indipendenti dal player."""
import json
from pathlib import Path
from competitions import COMPETITIONS, normalized

ROOT = Path(__file__).parent / "resources"
LEAGUES = json.loads((ROOT / "league-art.json").read_text(encoding="utf-8"))


def league_image(name, sport_id):
    key = normalized(name)
    for row in COMPETITIONS:
        if normalized(row["name"]) == key and row["image"]:
            return str(ROOT / row["image"])
    record = LEAGUES.get(key)
    return str(ROOT / "leagues" / record["file"] if record else ROOT / (sport_id + ".png"))
