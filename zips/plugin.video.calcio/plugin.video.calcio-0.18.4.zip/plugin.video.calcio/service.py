import xbmc
from updates import check_updates


if __name__ == "__main__":
    if not xbmc.Monitor().waitForAbort(20):
        check_updates()
