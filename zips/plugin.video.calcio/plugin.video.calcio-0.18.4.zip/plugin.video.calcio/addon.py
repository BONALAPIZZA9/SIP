import sys
import json
import re
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit

import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmc

from catalog import SPORTS, SourceError, get_events, get_sources, resolve_event, league_sort_key
from artwork import league_image
from competitions import canonical_league
from updates import check_updates
from events import MIRRORS


SPORT_LABELS = {"Calcio maschile": "Men's Football", "Calcio femminile": "Women's Football",
                "Pallavolo": "Volleyball", "Football americano": "American Football", "Basket": "Basketball"}
RESOURCES = Path(__file__).parent / "resources"
SPORT_STYLE = {
    "Calcio maschile": ("FF58D68D", "Explore men's football matches and competitions."),
    "Calcio femminile": ("FFFF80B5", "Explore women's football matches and competitions."),
    "Pallavolo": ("FFFFD166", "Volleyball fixtures and available broadcasts."),
    "Football americano": ("FF6CB6FF", "NFL, college football and other American football competitions."),
    "Basket": ("FFFFA45B", "Basketball fixtures, leagues and available broadcasts."),
    "Hockey": ("FF79E0EA", "Ice hockey fixtures and available broadcasts."),
    "Baseball": ("FFB3A1FF", "Baseball fixtures and available broadcasts."),
    "UFC": ("FFFF6B75", "UFC events and available broadcasts."),
    "F1": ("FFFF6767", "Formula 1 sessions and available broadcasts."),
}


def main():
    addon = xbmcaddon.Addon()
    handle = int(sys.argv[1])
    params = parse_qs(sys.argv[2].lstrip("?"))
    action = params.get("action", [""])[0]
    sport = params.get("sport", [""])[0]
    if sport == "Calcio":
        sport = "Calcio maschile"
    provider = params.get("provider", [""])[0]
    playing = action == "event_play"
    try:
        kodi_major = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
        xbmcplugin.setPluginCategory(handle, SPORT_LABELS.get(sport, sport) if sport in SPORTS else "SIP")
        xbmcplugin.setContent(handle, "files")
        if sport not in SPORTS:
            if playing:
                raise SourceError("Invalid match category.")
            check_updates()
            for name in SPORTS:
                xbmcgui.Window(10000).clearProperty("sip.provider." + name)
                target = sys.argv[0] + "?" + urlencode({"sport": name})
                label = SPORT_LABELS.get(name, name)
                color, plot = SPORT_STYLE[name]
                item = xbmcgui.ListItem(label="[B][COLOR {}]{}[/COLOR][/B]".format(color, label))
                if kodi_major >= 20:
                    info = item.getVideoInfoTag()
                    info.setTitle(label)
                    info.setPlot(plot)
                else:
                    item.setInfo("video", {"title": label, "plot": plot})
                image = str(RESOURCES / ("sport-v2-" + SPORTS[name] + ".png"))
                item.setArt({"thumb": image, "icon": image, "fanart": str(RESOURCES / "fanart.png")})
                xbmcplugin.addDirectoryItem(handle, target, item, True)
        elif playing:
            key = params.get("key", [""])[0]
            url = resolve_event(key, sport, int(params.get("source", ["0"])[0]))
            manifest, _, headers = url.partition("|")
            item = xbmcgui.ListItem(path=manifest)
            item.setContentLookup(False)
            item.setMimeType("application/vnd.apple.mpegurl")
            item.setProperty("inputstream", "inputstream.adaptive")
            if kodi_major < 21:
                item.setProperty("inputstream.adaptive.manifest_type", "hls")
            item.setProperty("inputstream.adaptive.manifest_headers", headers)
            item.setProperty("inputstream.adaptive.stream_headers", headers)
            if urlsplit(manifest).scheme == "https" and urlsplit(manifest).netloc in {urlsplit(base).netloc for base in MIRRORS}:
                version = xbmcaddon.Addon("inputstream.adaptive").getAddonInfo("version")
                if tuple(map(int, re.findall(r"\d+", version)[:3])) < (21, 4, 11):
                    raise SourceError("StreamFree certificate exception requires InputStream Adaptive 21.4.11 or newer. Update Kodi and InputStream Adaptive.")
                item.setProperty("inputstream.adaptive.config", json.dumps({"ssl_verify_peer": False}))
            xbmcplugin.setResolvedUrl(handle, True, item)
            return
        elif action == "event_links":
            key = params.get("key", [""])[0]
            provider = "terzino" if key.startswith("terzino:") else "zico" if key.startswith("zico:") else "streamfree"
            events = get_events(sport, provider)
            event = next((event for event in events if event["key"] == key), None)
            if not event:
                raise SourceError("This event has left the schedule. Reopen the category.")
            sources = get_sources(key, sport)
            for index in range(len(sources)):
                item = xbmcgui.ListItem(label="Player {} | {}".format(index + 1, event["title"]))
                item.setArt({"thumb": event["image"], "icon": event["image"], "fanart": str(RESOURCES / "fanart.png")})
                item.setProperty("IsPlayable", "true")
                target = sys.argv[0] + "?" + urlencode({"action": "event_play", "sport": sport, "key": key, "source": index})
                xbmcplugin.addDirectoryItem(handle, target, item, False)
            if not sources:
                xbmcgui.Dialog().ok(addon.getAddonInfo("name"), "No active player for this match. Try again near kick-off.")
        else:
            if not provider:
                window = xbmcgui.Window(10000)
                provider = window.getProperty("sip.provider." + sport)
                if provider not in ("zico", "streamfree", "terzino"):
                    choice = xbmcgui.Dialog().select("Choose provider", ["ZicoTV", "StreamFree", "Terzino"])
                    if choice < 0:
                        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
                        return
                    provider = ("zico", "streamfree", "terzino")[choice]
                    window.setProperty("sip.provider." + sport, provider)
            events = get_events(sport, provider)
            league = canonical_league(params.get("league", [""])[0], sport)
            if sport in ("Calcio maschile", "Calcio femminile", "Football americano") and not league:
                for name in sorted({event["league"] for event in events}, key=lambda name: league_sort_key(name, sport)):
                    target = sys.argv[0] + "?" + urlencode({"sport": sport, "league": name, "provider": provider})
                    item = xbmcgui.ListItem(label=name)
                    image = league_image(name, SPORTS[sport])
                    item.setArt({"thumb": image, "icon": image, "fanart": str(RESOURCES / "fanart.png")})
                    xbmcplugin.addDirectoryItem(handle, target, item, True)
                if not events:
                    xbmcgui.Dialog().ok(addon.getAddonInfo("name"), "No matches available today")
                xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
                return
            if league and sport in ("Calcio maschile", "Calcio femminile", "Football americano"):
                events = [event for event in events if event["league"] == league]
            for event in events:
                target = sys.argv[0] + "?" + urlencode({"action": "event_links", "sport": sport, "key": event["key"]})
                item = xbmcgui.ListItem(label="{} | {}".format(event["time"], event["title"]))
                item.setArt({"thumb": event["image"], "icon": league_image(event["league"], SPORTS[sport]),
                             "fanart": str(RESOURCES / "fanart.png")})
                xbmcplugin.addDirectoryItem(handle, target, item, True)
            if not events:
                xbmcgui.Dialog().ok(addon.getAddonInfo("name"), "No matches available today")
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    except (ValueError, OSError, KeyError, TypeError) as exc:
        if sport in SPORTS:
            xbmcgui.Window(10000).clearProperty("sip.provider." + sport)
        xbmc.log("SIP: {}: {}".format(type(exc).__name__, exc), xbmc.LOGERROR)
        message = str(exc) if isinstance(exc, SourceError) else "Unable to load the event or player. Reopen the category and try again."
        xbmcgui.Dialog().ok(addon.getAddonInfo("name"), message)
        if playing:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == "__main__":
    main()
