"""Eventi StreamFree: chiave evento e sorgenti fornite dalla stessa API."""
import json
import math
import re
from datetime import datetime
from pathlib import Path
from ssl import SSLCertVerificationError, SSLContext, PROTOCOL_TLS_CLIENT, CERT_NONE
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen, build_opener, HTTPSHandler, HTTPRedirectHandler

EVENT_SOURCE = "https://strmfree.st/"
# Published by https://strmfree.link/api/domains.
MIRRORS = (EVENT_SOURCE, "https://streamfree.top/")
SPORTS = {"Calcio maschile": "soccer", "Calcio femminile": "soccer", "Pallavolo": "volleyball", "Football americano": "football", "Basket": "basketball",
          "Hockey": "hockey", "Baseball": "baseball", "UFC": "combat", "F1": "racing"}
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36"


class SourceError(ValueError):
    pass


def matches_football(sport, league, title):
    if not sport.startswith("Calcio"):
        return True
    # shortcut: genere ricavato dai nomi della fonte, aggiornare i termini se cambia la classificazione.
    female = bool(re.search(r"women|female|femen|femmin|frauen|\b(?:nwsl|wsl|liga f)\b|\bW\b", league + " " + title, re.I))
    return female == (sport == "Calcio femminile")


def event_image(sport, base, *candidates):
    for value in candidates:
        if isinstance(value, str) and value.strip():
            try:
                return http_url(urljoin(base, value))
            except ValueError:
                pass
    return str(Path(__file__).parent / "resources" / (SPORTS[sport] + ".png"))


def http_url(value):
    parsed = urlsplit(value)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or any(c in value for c in "\r\n"):
        raise SourceError("Invalid source URL.")
    return value


class StreamFreeRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlsplit(newurl)
        if parsed.scheme != "https" or parsed.netloc not in {urlsplit(base).netloc for base in MIRRORS}:
            raise SourceError("StreamFree certificate exception cannot follow this redirect.")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_page(url, referer=EVENT_SOURCE):
    request = Request(http_url(url), headers={"User-Agent": USER_AGENT, "Referer": referer})
    try:
        try:
            response = urlopen(request, timeout=15)
        except URLError as exc:
            parsed = urlsplit(url)
            if not isinstance(exc.reason, SSLCertVerificationError) or parsed.scheme != "https" or parsed.netloc not in {urlsplit(base).netloc for base in MIRRORS}:
                raise
            # User-requested exception, restricted to StreamFree and its HTTPS redirects.
            context = SSLContext(PROTOCOL_TLS_CLIENT)
            context.check_hostname = False
            context.verify_mode = CERT_NONE
            response = build_opener(HTTPSHandler(context=context), StreamFreeRedirect()).open(request, timeout=15)
        with response:
            data = response.read(2 * 1024 * 1024 + 1)
            if len(data) > 2 * 1024 * 1024:
                raise SourceError("Source response is too large.")
            return data.decode("utf-8"), response.geturl()
    except HTTPError as exc:
        raise SourceError("StreamFree: HTTP {}. The link may be unavailable.".format(exc.code)) from exc
    except URLError as exc:
        if isinstance(exc.reason, SSLCertVerificationError):
            raise SourceError("The source HTTPS certificate could not be verified. Check the device date or try the other provider.") from exc
        raise SourceError("StreamFree is unreachable. Try again later.") from exc
    except (OSError, UnicodeError) as exc:
        raise SourceError("StreamFree is unreachable. Try again later.") from exc


def fetch_json(path, base=EVENT_SOURCE):
    for origin in dict.fromkeys((base, *MIRRORS)):
        try:
            return json.loads(fetch_page(urljoin(origin, path), origin)[0])
        except (ValueError, TypeError) as exc:
            error = exc if isinstance(exc, SourceError) else SourceError("Invalid StreamFree response.")
    raise error


def event_key(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,200}", value):
        raise SourceError("Invalid event key.")
    return value


def parse_events(data, sport):
    if not isinstance(data, dict) or not isinstance(data.get("streams"), dict):
        raise SourceError("The StreamFree schedule format has changed.")
    rows = data["streams"].get(SPORTS[sport], [])
    if not isinstance(rows, list):
        raise SourceError("Invalid StreamFree category.")
    events = []
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("name"), str) or not row["name"].strip():
            continue
        league = str(row.get("league", "")).strip().upper()
        if not matches_football(sport, league, row["name"]):
            continue
        if sport == "UFC" and league != "UFC":
            continue
        if sport == "F1" and league not in ("F1", "FORMULA 1", "FORMULA ONE"):
            continue
        try:
            key = event_key(row.get("stream_key"))
        except SourceError:
            continue
        if key in seen:
            continue
        timestamp = row.get("match_timestamp")
        if isinstance(timestamp, bool) or not isinstance(timestamp, (int, float)) or not math.isfinite(timestamp):
            continue
        try:
            time = datetime.fromtimestamp(timestamp).strftime("%d/%m %H:%M")
        except (ValueError, OverflowError, OSError):
            continue
        thumbnail = row.get("thumbnail_url")
        team = row.get("team1") if isinstance(row.get("team1"), dict) else {}
        away = row.get("team2") if isinstance(row.get("team2"), dict) else {}
        image = event_image(sport, EVENT_SOURCE, thumbnail, team.get("logo"), away.get("logo"))
        events.append({"key": key, "title": row["name"].strip(), "time": time,
                       "timestamp": timestamp, "sport": sport, "image": image,
                       "league": str(row.get("league") or "").strip() or "Other competitions"})
        seen.add(key)
    return sorted(events, key=lambda event: event["timestamp"])


def get_events(sport):
    data = fetch_json("/api/v1/streams?" + urlencode({"category": SPORTS[sport]}))
    if not isinstance(data, dict) or not isinstance(data.get("streams"), list):
        raise SourceError("The StreamFree API format has changed.")
    rows = [row for row in data["streams"] if isinstance(row, dict) and row.get("category") == SPORTS[sport]]
    return parse_events({"streams": {SPORTS[sport]: rows}}, sport)


def get_sources(key, sport):
    key = event_key(key)
    if not any(event["key"] == key for event in get_events(sport)):
        raise SourceError("This event has left the schedule. Reopen the category.")
    data = fetch_json("/api/v1/sources/" + quote(key, safe=""))
    if not isinstance(data, dict) or data.get("stream_key") != key or not isinstance(data.get("sources"), list):
        raise SourceError("The source did not confirm this match.")
    sources = []
    for source in data["sources"]:
        if not isinstance(source, str) or any(c in source for c in "\r\n"):
            continue
        try:
            parsed = urlsplit(source)
        except ValueError:
            continue
        if parsed.scheme == "https" and parsed.netloc in {urlsplit(base).netloc for base in MIRRORS} and not parsed.query and not parsed.fragment:
            # Accetta solo gli embed che l'API assegna espressamente all'evento.
            if re.fullmatch(r"/embed/" + SPORTS[sport] + "/" + re.escape(key) + r"(?:[0-9]+p[0-9]*)?", parsed.path) and source not in sources:
                sources.append(source)
    return sorted(sources)


def resolve_event(key, sport, source_index=0, source_url=None):
    sources = get_sources(key, sport)
    if source_url is not None:
        if source_url not in sources:
            raise SourceError("The selected player is no longer available. Reopen the match.")
        source_index = sources.index(source_url)
    if not 0 <= source_index < len(sources):
        raise SourceError("Player unavailable: the broadcast may not have started yet.")
    embed = sources[source_index]
    base = "https://" + urlsplit(embed).netloc + "/"
    player_path = "player/{}/{}".format(SPORTS[sport], quote(key, safe=""))
    for origin in dict.fromkeys((base, *MIRRORS)):
        try:
            html, final = fetch_page(urljoin(origin, urlsplit(embed).path), urljoin(origin, player_path))
            break
        except SourceError as exc:
            error = exc
    else:
        raise error
    if urlsplit(final).netloc not in {urlsplit(origin).netloc for origin in MIRRORS} or urlsplit(final).scheme != "https" or urlsplit(final).path != urlsplit(embed).path:
        raise SourceError("The player changed domain. Link rejected.")
    embed = final
    base = "https://" + urlsplit(embed).netloc + "/"
    quality = re.search(r"const QUALITY\s*=\s*['\"]([0-9]+p)['\"]", html)
    suffix = re.search(r"const SOURCE_SUFFIX\s*=\s*['\"]([0-9]*)['\"]", html)
    variant = re.search(r"const VARIANT\s*=\s*['\"]([^'\"]+)['\"]\s*\+\s*QUALITY\s*\+\s*SOURCE_SUFFIX", html)
    tokens = re.search(r"const _0x\s*=\s*(\{[^;]+\})\s*;", html)
    if not all((quality, suffix, variant, tokens)) or variant[1] != key:
        raise SourceError("The player did not confirm the match key or its format has changed.")
    try:
        authorization = json.loads(tokens[1])[quality[1]]
        if any(not isinstance(authorization.get(field), (str, int)) for field in ("_t", "_e", "_n")):
            raise ValueError()
    except (ValueError, KeyError, TypeError) as exc:
        raise SourceError("Player authorization unavailable.") from exc
    routing = fetch_json("/get-stream-key/" + quote(key, safe=""), base)
    if not isinstance(routing, dict) or routing.get("stream_key") != key:
        raise SourceError("The server did not confirm the match key.")
    if routing.get("is_external"):
        raise SourceError("This event requires an unsupported external player.")
    folder = "live-cdn" if routing.get("server_name", "origin") != "origin" else "live"
    path = "/{}/{}/index.m3u8".format(folder, quote(key + quality[1] + suffix[1], safe=""))
    stream = urljoin(base, path) + "?" + urlencode({field: authorization[field] for field in ("_t", "_e", "_n")})
    headers = {"User-Agent": USER_AGENT, "Referer": embed, "Origin": base.rstrip("/")}
    return stream + "|" + urlencode(headers)
