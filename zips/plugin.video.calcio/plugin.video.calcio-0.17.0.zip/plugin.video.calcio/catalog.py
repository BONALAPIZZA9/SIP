"""Unisce le due fonti conservando gli identificativi, senza abbinamenti per nome."""
import logging
import re
import unicodedata
import events
import zico
from events import SPORTS, SourceError
from competitions import canonical_league, normalized


def league_sort_key(name, sport):
    text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    if sport == "Football americano":
        priorities = (r"\bnfl\b|national football league", r"\bncaa\b|\bncaaf\b|college football",
                      r"\bcfl\b|canadian football league", r"\bufl\b|united football league",
                      r"european league of football|\belf\b")
    else:
        priorities = (r"world cup|mundial|coppa del mondo", r"women.s champions league|uefa champions league|^champions league$|liga de campeones",
                      r"\beuro(?:pean championship)?\b|copa america", r"europa league",
                      r"conference league", r"women.s serie a|italian serie a|^serie a(?: femminile)?$|italia: serie a",
                      r"english premier league|^premier league$|english women|womens super league|\bwsl\b", r"la liga|laliga|liga f\b",
                      r"women.s bundesliga|german bundesliga|^bundesliga(?: femminile)?$|alemania.*bundesliga", r"women.s premiere ligue|ligue 1|premiere ligue", r"\bnwsl\b",
                      r"eredivisie|primeira liga|liga portugal", r"\bmls\b|major league soccer",
                      r"champions league", r"premier league|super league")
    # shortcut: priorita editoriali per nome, aggiornare i termini se le fonti cambiano denominazione.
    rank = next((i for i, pattern in enumerate(priorities) if re.search(pattern, text)), 100)
    if re.search(r"\bu(?:nder)?[ -]?(?:17|19|20|21|23)\b|youth|giovanil|amistos|friendly", text):
        rank = 90
    if name == "Other competitions":
        rank = 101
    return rank, text


def get_events(sport, selected_provider=None):
    result = []
    errors = []
    providers = {"streamfree": events, "zico": zico}
    if selected_provider is not None and selected_provider not in providers:
        raise SourceError("Invalid provider.")
    for provider in ((providers[selected_provider],) if selected_provider else (events, zico)):
        try:
            result.extend(provider.get_events(sport))
        except (SourceError, OSError) as exc:
            errors.append(str(exc))
            logging.warning("Event source unavailable: %s", exc)
    if not result and errors:
        raise SourceError("Unable to load the schedule. " + " ".join(errors))
    labels = {}
    for event in result:
        if "league" in event:
            name = canonical_league(event["league"], sport)
            event["league"] = labels.setdefault(normalized(name), name)
    return sorted(result, key=lambda event: event["timestamp"])


def get_sources(key, sport):
    return (zico if key.startswith("zico:") else events).get_sources(key, sport)


def resolve_event(key, sport, source_index=0):
    return (zico if key.startswith("zico:") else events).resolve_event(key, sport, source_index)
